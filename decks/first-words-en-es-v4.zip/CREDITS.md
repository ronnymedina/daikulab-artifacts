# Créditos — Primeras palabras

| Palabra | Recurso | Autor | Licencia | Fuente |
|---|---|---|---|---|
| milk | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| milk | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| water | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| water | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| apple | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| apple | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| banana | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| banana | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| bread | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| bread | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| dog | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| dog | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| cat | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| cat | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| ball | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| ball | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| car | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| car | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| sun | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| sun | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| egg | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| egg | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| cheese | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| cheese | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| cake | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| cake | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| pizza | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| pizza | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| strawberry | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| strawberry | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| carrot | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| carrot | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| juice | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| juice | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| candy | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| candy | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| rice | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| rice | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| watermelon | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| watermelon | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| pear | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| pear | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| corn | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| corn | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| ice cream | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| ice cream | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| cookie | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| cookie | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| orange | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| orange | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| grape | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| grape | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| bird | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| bird | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| fish | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| fish | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| horse | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| horse | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| cow | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| cow | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| pig | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| pig | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| duck | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| duck | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| rabbit | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| rabbit | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| lion | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| lion | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| elephant | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| elephant | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| monkey | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| monkey | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| bear | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| bear | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| frog | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| frog | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| chicken | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| chicken | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| sheep | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| sheep | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| tiger | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| tiger | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| mouse | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| mouse | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| turtle | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| turtle | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| snake | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| snake | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| giraffe | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| giraffe | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| owl | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| owl | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| bee | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| bee | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| ant | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| ant | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| butterfly | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| butterfly | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| hand | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| hand | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| eye | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| eye | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| ear | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| ear | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| nose | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| nose | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| mouth | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| mouth | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| foot | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| foot | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| tooth | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| tooth | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| hair | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| hair | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| baby | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| baby | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| boy | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| boy | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| girl | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| girl | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| house | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| house | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| bed | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| bed | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| chair | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| chair | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| door | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| door | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| window | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| window | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| cup | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| cup | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| spoon | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| spoon | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| toothbrush | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| toothbrush | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| phone | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| phone | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| clock | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| clock | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| key | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| key | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| umbrella | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| umbrella | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| school | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| school | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| book | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| book | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| pencil | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| pencil | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| crayon | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| crayon | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| scissors | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| scissors | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| gift | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| gift | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| balloon | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| balloon | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| kite | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| kite | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| teddy bear | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| teddy bear | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| shoe | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| shoe | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| hat | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| hat | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| shirt | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| shirt | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| dress | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| dress | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| pants | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| pants | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| socks | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| socks | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| glasses | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| glasses | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| bus | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| bus | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| train | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| train | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| airplane | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| airplane | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| boat | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| boat | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| bicycle | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| bicycle | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| truck | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| truck | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| rocket | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| rocket | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| moon | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| moon | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| star | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| star | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| tree | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| tree | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| flower | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| flower | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| rain | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| rain | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| cloud | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| cloud | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| snow | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| snow | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| rainbow | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| rainbow | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| fire | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| fire | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| red | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| red | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| blue | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| blue | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| green | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| green | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| yellow | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| yellow | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
| heart | imagen | Gemini (gemini-3.1-flash-lite-image, estilo kawaii) | Generado con IA | https://ai.google.dev/gemini-api/docs/image-generation |
| heart | audio | Gemini TTS (gemini-3.8-flash-tts, voz sulafat) | Generado con IA | https://ai.google.dev/gemini-api/docs/speech-generation |
